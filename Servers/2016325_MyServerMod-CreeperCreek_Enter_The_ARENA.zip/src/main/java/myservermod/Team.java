package myservermod;

import com.youthdigital.servermod.game.*;

public class Team extends TeamData {
  
  public Team(String blockName, String teamDisplayName, ChatColors teamColor) {
    super(blockName, teamDisplayName, teamColor);
  }
  
  @Override
  public void onUpdate() {
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
}