package myservermod;

import com.youthdigital.servermod.game.*;

public class Player extends PlayerData {
  
  public Player(EntityPlayer parPlayerObject) {
    super(parPlayerObject);
  }
  
  @Override
  public void onUpdate() {
    
    if (Conditions.didRightClickBlock("redTeamJoin")) {
      Actions.teleportPlayers("redTeamBase");
    }
    
    if (Conditions.didRightClickBlock("blueTeamJoin")) {
      Actions.teleportPlayers("blueTeamBase");
    }
    
    if (Conditions.isStandingOnBlock("health") && Conditions.secondsGoneBy(2)) {
      Actions.restoreHealth(3);
      Actions.restoreHunger(3);
    }
    
  }
  
  @Override
  public void onJoinedServer(){
    
    Actions.teleportPlayers("lobbySpawn");
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onRespawned() {
    
    Actions.teleportPlayers("lobbySpawn");
    
  }
  
}