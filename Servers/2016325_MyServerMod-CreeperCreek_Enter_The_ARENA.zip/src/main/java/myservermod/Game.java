package myservermod;

import com.youthdigital.servermod.game.*;

public class Game extends TeamData {
  
  public Game(ChatColors teamColor, String teamNameDisplay) {
    super("All Players", teamColor, teamNameDisplay);
  }
  
  public static void setupGameRules() {
    
    GameInfo.setServerDescription("A Minecraft Server By onbekendegozer");
    GameInfo.addToWhitelist("onbekendegozer, IsabelleSolange, Mees05, Berebouwer, willempie606, finnie808, Bobdie, onbekendegast");
    GameInfo.addToOPs("onbekendegozer, IsabelleSolange, onbekendegast");
    
    GameInfo.disableBlockBreaking();
    GameInfo.disableMobSpawning();
    
    GameInfo.setTime(12000);
    GameInfo.setDifficulty(3);
    GameInfo.isRaining(false);
    GameInfo.setPVP(false);
    
    Welcome.setWelcomeMessage("Welcome To The Server!", "Have Fun!");
    Welcome.setWelcomeSound("mob.wither.spawn");
    
  }
  
  @Override
  public void onUpdate() {
    
    if (Conditions.secondsGoneBy(2)) {
      Actions.spawnEntityInRange("zombieSpawn", 10, EntityZombie.class, 3);
    }
    
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
}