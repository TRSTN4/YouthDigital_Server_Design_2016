package myservermod;

import com.youthdigital.servermod.game.*;

public class Player extends PlayerData {
  
  
  
  public int credits = 1;
  
  /* VARIABLES */
  public Player(EntityPlayer parPlayerObject) {
    super(parPlayerObject);
  }
  
  @Override
  public void onUpdate() {
    
/* SPECIAL BLOCKS */    
    
    // join blocks
    if (Conditions.didRightClickBlock("redTeamJoin")) {
      GameManager.joinTeam("redTeam");
      Actions.startCountdown(30);
    }
    
    if (Conditions.didRightClickBlock("blueTeamJoin")) {
      GameManager.joinTeam("blueTeam");
      Actions.startCountdown(30);
    }
    
    // healing block
    if (Conditions.isStandingOnBlock("health") && Conditions.secondsGoneBy(2)) {
      Actions.restoreHealth(3);
      Actions.restoreHunger(3);
    }
    
/* STORE */
    
    // archer
    if (Conditions.didRightClickBlock("archer") && credits >= 1) {
      Actions.giveItems(Items.bow, Enchantment.infinity, 3, Enchantment.punch, 2, Items.arrow, 64,
                       Items.chainmail_helmet, Enchantment.unbreaking, 2,
                       Items.chainmail_chestplate, Enchantment.unbreaking, 2,
                       Potion.moveSpeed, 10000, 0);
      Actions.displayChatMessage("Aim true, archer!");
      credits = credits - 1;
    }
    
    // knight
    if (Conditions.didRightClickBlock("knight") && credits >= 1) {
      Actions.giveItems(Items.iron_sword, Enchantment.unbreaking, 3, Enchantment.knockback, 1,
                       Items.iron_helmet, Enchantment.unbreaking, 2, Enchantment.fireProtection, 1,
                       Items.iron_chestplate, Enchantment.unbreaking, 2, Enchantment.fireProtection, 1, 
                       Items.iron_leggings, Enchantment.unbreaking, 2, Enchantment.fireProtection, 1, 
                       Items.iron_boots, Enchantment.unbreaking, 2, Enchantment.fireProtection, 1,
                       Potion.moveSlowdown, 10000, 1);
      Actions.displayChatMessage("I dub thee knight!");
      credits = credits - 1;
    }
   
/* DISPLAY */
    if (credits > 0) {
      Actions.displaySmallInfo("Credits: " + credits);
    }
  if (GameManager.isGameActive()) {
    if (Game.secondsLeft > 9) {
      Actions.displaySmallInfo(getTeamChatColor() + getTeamDisplayName() + " - " + Game.minutesLeft + ":" + Game.secondsLeft);
    } else {
      Actions.displaySmallInfo(getTeamChatColor() + getTeamDisplayName() + " - " + Game.minutesLeft + ":0" + Game.secondsLeft);
    }
 
    }
  }
  
  
  @Override
  public void onJoinedServer(){
    
    Actions.teleportPlayers("lobbySpawn");
    
  }
  
  @Override
  public void onStartGame() {
    
    Actions.teleportPlayers(getTeamBase());
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
    credits = 1;
    Actions.restoreHealth(20);
    Actions.restoreHunger(20);
    Actions.clearPotions();
    Actions.removeItems();
    Actions.teleportPlayers("lobbySpawn");
    
  }
  
  @Override
  public void onRespawned() {
    
    Actions.teleportPlayers(getTeamBase());
    
  }
  
}