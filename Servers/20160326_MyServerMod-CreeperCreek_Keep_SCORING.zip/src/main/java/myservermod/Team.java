package myservermod;

import com.youthdigital.servermod.game.*;

public class Team extends TeamData {
  
  public Team(String blockName, String teamDisplayName, ChatColors teamColor) {
    super(blockName, teamDisplayName, teamColor);
  }
  
  @Override
  public void onUpdate() {
    
    /* MOB POINTS */
    
    // zombies
    if (Conditions.mobDestroyed(EntityZombie.class)) {
      points += 3;
    }
    
    // skeletons
    if (Conditions.mobDestroyed(EntitySkeleton.class)) {
      points += 2;
    }
    
    // spiders
    if (Conditions.mobDestroyed(EntitySpider.class)) {
      points += 3;
    }
    
    // creepers
    if (Conditions.mobDestroyed(EntityCreeper.class)) {
      points += 5;
    }
    
    // player
    if (Conditions.playerDied()) {
      points -= 5;
    }
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
}