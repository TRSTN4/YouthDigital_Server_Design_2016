package myservermod;

import com.youthdigital.servermod.game.*;

public class Game extends TeamData {
  
  public Game(ChatColors teamColor, String teamNameDisplay) {
    super("All Players", teamColor, teamNameDisplay);
  }
  
  public static void setupGameRules() {
    
    GameInfo.setServerDescription("A Minecraft Server By onbekendegozer");
    GameInfo.addToWhitelist("onbekendegozer, IsabelleSolange, Mees05, Berebouwer, willempie606, finnie808, Bobdie, onbekendegast");
    GameInfo.addToOPs("onbekendegozer, IsabelleSolange, onbekendegast");
    
  }
  
  @Override
  public void onUpdate() {
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
}