package myservermod;

import com.youthdigital.servermod.game.*;

public class Player extends PlayerData {
  
  public Player(EntityPlayer parPlayerObject) {
    super(parPlayerObject);
  }
  
  @Override
  public void onUpdate() {
    
  }
  
  @Override
  public void onJoinedServer(){
    
  }
  
  @Override
  public void onStartGame() {
    
  }
  
  @Override
  public void onResetGameToLobby() {
    
  }
  
  @Override
  public void onRespawned() {
    
  }
  
}